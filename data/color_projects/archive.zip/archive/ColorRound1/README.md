# Put your color image algorithms here.
I have included a template for you to hand out with a sample algorithm.